"""Pruebas unitarias e integración (no se llama a ninguna API externa)."""
import copy
from io import BytesIO

import pytest
from docx import Document

from core import storage
from core.config import ConfigurationError,validate_config
from core.extraction import interpret_document,read_document,validate_upload
from core.evaluation import days_union, merge_periods, ACCREDITED, FAILED, PENDING, NOT_ACCREDITED
from core.reports import pdf_candidate, csv_bytes, excel_bytes
from core.service import run_analysis,case_result,classification
from datetime import date


@pytest.fixture()
def db(tmp_path):
    path=tmp_path/'prototipo.sqlite'
    storage.initialize(path)
    return path


def make_docx(lines):
    d=Document()
    for line in lines:d.add_paragraph(line)
    bio=BytesIO();d.save(bio)
    return bio.getvalue()


def test_seed_and_rule_validation(db):
    assert len(storage.vacancies(db))==2
    c=storage.get_config('TR-DEMO-001',db)
    validate_config(c)
    assert sum(m['max_points'] for m in c['merits'])==45
    assert len(storage.list_candidates('TR-DEMO-001',db))==4
    assert storage.list_documents('TR-DEMO-001','C-001',db)


def test_extract_docx_fields_and_evidence(db):
    doc=storage.list_documents('TR-DEMO-001','C-001',db)[0]
    raw=storage.get_document(doc['id'],'TR-DEMO-001','C-001',db)
    extracted=interpret_document(raw)
    assert extracted['evidence']
    assert extracted['mode']=='demostracion_sin_ia'
    assert extracted['fixture']


def test_analysis_candidate_c001_max_and_overlap(db):
    run_analysis('TR-DEMO-001','C-001',db_path=db)
    case=case_result('TR-DEMO-001','C-001',db)
    assert all(r['status']==ACCREDITED for r in case['result']['requirements'])
    assert {m['id']:m['points'] for m in case['result']['merits']}=={'M-EXP':20,'M-FOR':15,'M-OTR':5}
    assert case['result']['total']==40
    assert not case['validated']
    assert case['status']=='Elegible pendiente de validación'


def test_license_expiry_is_verified_but_missing_title_is_not(db):
    run_analysis('TR-DEMO-001','C-002',db_path=db)
    reqs={r['id']:r for r in case_result('TR-DEMO-001','C-002',db)['result']['requirements']}
    assert reqs['R-CAR']['status']==FAILED
    run_analysis('TR-DEMO-001','C-003',db_path=db)
    reqs={r['id']:r for r in case_result('TR-DEMO-001','C-003',db)['result']['requirements']}
    assert reqs['R-TIT']['status']==NOT_ACCREDITED
    assert reqs['R-EXP']['status']==PENDING


def test_union_no_double_count():
    a=date(2026,1,1);b=date(2026,1,31);c=date(2026,1,15);d=date(2026,2,10)
    assert days_union([(a,b),(c,d)])==41
    assert len(merge_periods([(a,b),(c,d)]))==1


def test_all_merits_capped_45(db):
    for c in storage.vacancies(db):
        for person in storage.list_candidates(c['code'],db):
            run_analysis(c['code'],person['candidate'],db_path=db)
            case=case_result(c['code'],person['candidate'],db)
            assert 0<=case['result']['total']<=45
            assert all(m['points']<=m['max_points'] for m in case['result']['merits'])


def test_manual_correction_and_human_validation(db):
    a=run_analysis('TR-DEMO-001','C-001',db_path=db)
    storage.save_review('TR-DEMO-001','C-001',a['id'],'merit','M-OTR',{'points':0,'reason':'Revisión de autenticidad'},
        'tecnico_prueba','Revisión de autenticidad',db)
    case=case_result('TR-DEMO-001','C-001',db)
    assert case['result']['total']==35
    assert not case['validated']
    storage.validate_eligibility('TR-DEMO-001','C-001',a['id'],'tecnico_prueba',db)
    assert case_result('TR-DEMO-001','C-001',db)['validated']
    assert classification('TR-DEMO-001',db)[0]['Posición']==1
    records=storage.audit_list('TR-DEMO-001',db)
    assert any(r['action']=='manual_review' for r in records)
    assert any(r['action']=='eligibility_validated' for r in records)


def test_modified_docs_require_reanalysis_preserve_history(db):
    a=run_analysis('TR-DEMO-001','C-001',db_path=db)
    storage.save_review('TR-DEMO-001','C-001',a['id'],'merit','M-OTR',{'points':0,'reason':'Criterio humano'},'tec','Criterio humano',db)
    storage.validate_eligibility('TR-DEMO-001','C-001',a['id'],'tec',db)
    raw=make_docx(['CURSO','Nombre: Nuevo curso','Tema: sostenibilidad','Horas: 50','Entidad: Centro ficticio','Fecha: 2025-01-01'])
    storage.add_document('TR-DEMO-001','C-001','nuevo.docx','curso',validate_upload('nuevo.docx',raw),raw,'tec',db)
    assert case_result('TR-DEMO-001','C-001',db) is None
    b=run_analysis('TR-DEMO-001','C-001',db_path=db)
    assert b['id']!=a['id']
    assert not case_result('TR-DEMO-001','C-001',db)['validated']
    assert storage.previous_reviews('TR-DEMO-001','C-001',db)
    assert ('merit','M-OTR') not in storage.get_reviews(b['id'],db)


def test_unchanged_analysis_is_stable(db):
    a=run_analysis('TR-DEMO-001','C-001',db_path=db)
    b=run_analysis('TR-DEMO-001','C-001',db_path=db)
    assert a['id']==b['id']


def test_invalid_configuration_must_be_rejected(db):
    config=storage.get_config('TR-DEMO-001',db)
    config['merits'][0]['max_points']=21
    with pytest.raises(ConfigurationError):validate_config(config)
    config['merits'][0]['max_points']=30
    with pytest.raises(ConfigurationError):validate_config(config)
    config['merits'][0]['max_points']=20
    del config['merits'][0]['rule']['days_per_block']
    with pytest.raises(ConfigurationError):validate_config(config)


def test_config_change_invalidates_old_scores(db):
    old=run_analysis('TR-DEMO-001','C-001',db_path=db)
    cfg=storage.get_config('TR-DEMO-001',db)
    cfg['merits'][1]['rule']['thresholds'][0]['min_hours']=30
    storage.save_config('TR-DEMO-001',cfg,'tec',db)
    assert case_result('TR-DEMO-001','C-001',db) is None
    new=run_analysis('TR-DEMO-001','C-001',db_path=db)
    assert new['id']!=old['id']


def test_report_exports(db):
    run_analysis('TR-DEMO-001','C-001',db_path=db)
    case=case_result('TR-DEMO-001','C-001',db)
    config=storage.get_config('TR-DEMO-001',db)
    pdf=pdf_candidate(case,config)
    assert pdf.startswith(b'%PDF') and len(pdf)>1000
    csv=csv_bytes([{'Expediente':'C-001','Puntos':40}])
    assert b'C-001' in csv
    assert excel_bytes({'Clasificacion':[{'Candidatura':'C-001'}]}).startswith(b'PK')


def test_read_empty_or_bad_files():
    with pytest.raises(ValueError):validate_upload('mal.pdf',b'no es un pdf')
    with pytest.raises(ValueError):validate_upload('archivo.exe',b'123')
    raw=make_docx(['CERTIFICADO DE EMPRESA','Funciones: gestion ambiental','Inicio: 2026-05-01','Fin: 2025-01-01'])
    p,issues=read_document(raw,'inconsistente.docx')
    doc=interpret_document({'id':'test','filename':'inconsistente.docx','category':'certificado_empresa',
        'fixture':0,'content':raw})
    assert p[0]['text']
    assert any('contradictori' in x for x in doc['issues'])


def test_configured_tie_breaker_only(db):
    cfg=storage.get_config('TR-DEMO-001',db)
    cfg['tie_breakers']=[{'merit_id':'M-FOR','direction':'desc'}]
    storage.save_config('TR-DEMO-001',cfg,'tecnico',db)
    a=run_analysis('TR-DEMO-001','C-001',db_path=db)
    b=run_analysis('TR-DEMO-001','C-004',db_path=db)
    storage.save_review('TR-DEMO-001','C-001',a['id'],'merit','M-FOR',{'points':5,'reason':'Prueba'},'tec','Prueba',db)
    storage.validate_eligibility('TR-DEMO-001','C-001',a['id'],'tec',db)
    storage.validate_eligibility('TR-DEMO-001','C-004',b['id'],'tec',db)
    ranks=classification('TR-DEMO-001',db)
    assert ranks[0]['Candidatura']=='C-004' and ranks[0]['Posición']==1
    assert ranks[1]['Candidatura']=='C-001' and ranks[1]['Posición']==2
