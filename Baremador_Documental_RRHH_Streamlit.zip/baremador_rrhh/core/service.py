"""Orquestación de expedientes y clasificación sin decisiones automáticas finales."""
from __future__ import annotations
from core import storage
from core.extraction import interpret_document
from core.evaluation import effective_result, evaluate_case, ACCREDITED, FAILED, PENDING


def run_analysis(vacancy,candidate,api_key=None,model='gpt-4o-mini',db_path=None):
    # Un mismo conjunto de documentos + versión de bases conserva la misma validación.
    existing=storage.get_analysis(vacancy,candidate,db_path)
    if existing:return existing
    config=storage.get_config(vacancy,db_path)
    docs=[]
    for doc in storage.list_documents(vacancy,candidate,db_path):
        raw=storage.get_document(doc['id'],vacancy,candidate,db_path)
        if raw:docs.append(interpret_document(raw,api_key=api_key,model=model))
    result=evaluate_case(config,docs)
    storage.save_analysis(vacancy,candidate,result,db_path=db_path)
    return storage.get_analysis(vacancy,candidate,db_path)


def case_result(vacancy,candidate,db_path=None):
    ana=storage.get_analysis(vacancy,candidate,db_path)
    if not ana:return None
    effective=effective_result(ana,storage.get_reviews(ana['id'],db_path))
    eligible=all(r['status']==ACCREDITED for r in effective['requirements'])
    validated=eligible and storage.is_validated(ana['id'],db_path)
    if validated:status='Validado y elegible'
    elif any(r['status']==FAILED for r in effective['requirements']):status='Incumplimiento (provisional)'
    elif any(r['status']==PENDING for r in effective['requirements']):status='Pendiente de revisión'
    elif not eligible:status='No acreditado (provisional)'
    else:status='Elegible pendiente de validación'
    return {'analysis_id':ana['id'],'vacancy':vacancy,'candidate':candidate,'result':effective,
            'status':status,'validated':validated,'eligible':eligible,'date':ana['created_at']}


def classification(vacancy,db_path=None):
    config=storage.get_config(vacancy,db_path)
    tiebreak=config.get('tie_breakers',[])
    rows=[]
    for candidate in storage.list_candidates(vacancy,db_path):
        res=case_result(vacancy,candidate['candidate'],db_path)
        if not res:
            rows.append({'Candidatura':candidate['candidate'],'Estado':'Sin análisis','Puntos':None,
                         'Validado':False,'Definitivo':False,'Posición':None,'Incidencias':0,'_tie':{}})
            continue
        issues=res['result']['document_issues']
        inc=len(issues)+sum(r['status'] in (PENDING,FAILED) for r in res['result']['requirements'])
        scores={m['id']:m['points'] for m in res['result']['merits']}
        rows.append({'Candidatura':candidate['candidate'],'Estado':res['status'],'Puntos':res['result']['total'],
                     'Validado':res['validated'],'Definitivo':res['validated'],'Posición':None,'Incidencias':inc,
                     '_tie':scores})
    # Los desempates solo se calculan con criterios expresamente aprobados en la convocatoria.
    def sort_key(row):
        return (-row['Puntos'],)+tuple((-1 if t['direction']=='desc' else 1)*row['_tie'].get(t['merit_id'],0)
            for t in tiebreak)
    ranked=sorted([r for r in rows if r['Definitivo']],key=sort_key)
    position=0;last_key=None
    for i,row in enumerate(ranked):
        key=sort_key(row)
        if key!=last_key:position=i+1
        row['Posición']=position
        last_key=key
    ordered=sorted(rows,key=lambda x:(not x['Definitivo'],-(x['Puntos'] if x['Puntos'] is not None else -1),
        x['Candidatura']))
    # Poner en el orden correcto los definitivos cuando hay empate con desempate explícito.
    ordered=ranked+[r for r in ordered if not r['Definitivo']]
    return [{k:v for k,v in row.items() if k!='_tie'} for row in ordered]
