"""Verificador de requisitos y motor de puntuación 100 % determinista."""
from __future__ import annotations

from datetime import date, timedelta
from math import floor
from core.extraction import normalize

ACCREDITED='Acreditado'
NOT_ACCREDITED='No acreditado'
FAILED='Incumplimiento verificado'
PENDING='Pendiente de revisión'
STATES=(ACCREDITED,NOT_ACCREDITED,FAILED,PENDING)


def valid_date(value):
    try: return date.fromisoformat(str(value))
    except (ValueError,TypeError):return None


def merge_periods(intervals):
    """Unión inclusiva de intervalos, sin contabilizar un día dos veces."""
    clean=sorted((s,e) for s,e in intervals if isinstance(s,date) and isinstance(e,date) and s<=e)
    merged=[]
    for begin,end in clean:
        if merged and begin<=merged[-1][1]+timedelta(days=1):
            merged[-1]=(merged[-1][0],max(merged[-1][1],end))
        else:merged.append((begin,end))
    return merged


def days_union(intervals):
    return sum((e-s).days+1 for s,e in merge_periods(intervals))


def keyword_matches(value,phrases):
    txt=normalize(value)
    return bool(txt) and any(normalize(k) in txt for k in phrases)


def ref_for(doc,field_names=None):
    refs=[{'doc_id':doc['doc_id'],'filename':doc['filename'],'page':r['page'],'quote':r['quote']}
          for r in doc['evidence'] if field_names is None or r['field'] in field_names]
    return refs[:8]


def relevant_issues(docs, categories):
    return any(d['issues'] for d in docs if d['category'] in categories)


def eligible_experience(docs,cutoff,keywords):
    intervals=[];refs=[];uncertain=[]
    for d in docs:
        if d['category'] not in ('certificado_empresa','contrato','vida_laboral'):continue
        f=d['fields']
        if d['category']=='vida_laboral':
            uncertain.append('La vida laboral por sí sola no acredita las funciones exigidas.')
            continue
        if not keyword_matches(f.get('functions',''),keywords):
            uncertain.append(f"{d['filename']}: no constan funciones específicas verificables.")
            continue
        start=valid_date(f.get('start_date'));end=valid_date(f.get('end_date'))
        if not start or not end:
            uncertain.append(f"{d['filename']}: fechas incompletas o no normalizadas.")
            continue
        if start>end:
            uncertain.append(f"{d['filename']}: periodo contradictorio.")
            continue
        if start>cutoff:continue
        intervals.append((start,min(end,cutoff)))
        refs+=ref_for(d,['start_date','end_date','functions'])
    return days_union(intervals),refs,uncertain


def eligible_courses(docs,cutoff,topics,min_hours=0):
    eligible=[];issues=[];seen={}
    for d in docs:
        if d['category']!='curso':continue
        f=d['fields']; title=f.get('course_name','');topic=f.get('topic','')
        if not keyword_matches(f'{title} {topic}',topics):continue
        hours=f.get('hours')
        issued=valid_date(f.get('issue_date'))
        if not isinstance(hours,int) or hours < 0 or not issued:
            issues.append(f"{d['filename']}: horas o fecha sin acreditar.")
            continue
        if issued>cutoff:
            issues.append(f"{d['filename']}: expedido después de la fecha de referencia.")
            continue
        if hours<min_hours:continue
        key=(normalize(title),normalize(f.get('issuer','')),issued.isoformat())
        if key in seen:
            if seen[key]!=hours:
                issues.append(f"{d['filename']}: duplicado con horas contradictorias.")
            continue
        seen[key]=hours
        eligible.append({'hours':hours,'refs':ref_for(d,['course_name','topic','hours','issue_date']),
                         'doc_id':d['doc_id'],'title':title})
    return eligible,issues


def evaluate_requirement(rule,docs,cutoff):
    kind=rule['type'];result={'id':rule['id'],'label':rule['label'],'status':NOT_ACCREDITED,'reason':'No se han localizado pruebas suficientes.',
        'evidence':[]}
    if kind=='degree':
        degrees=[d for d in docs if d['category']=='titulacion']
        matched=[]
        for d in degrees:
            title=normalize(d['fields'].get('degree_name',''))
            issued=valid_date(d['fields'].get('issue_date'))
            allowed=[normalize(t) for t in rule['allowed_titles']]
            if title in allowed and issued and issued<=cutoff:
                matched.append(d)
        if matched:
            result.update(status=ACCREDITED,reason='Título literal admitido y expedido en plazo (equivalencias no inferidas).',
                          evidence=ref_for(matched[0],['degree_name','issue_date']))
        elif any(normalize(d['fields'].get('degree_name','')) in [normalize(t) for t in rule['allowed_titles']]
                 for d in degrees):
            result.update(status=PENDING,reason='Existe un título admitido, pero la fecha de expedición no es comprobable o está fuera de plazo; revisión humana.',
                          evidence=[r for d in degrees for r in ref_for(d,['degree_name','issue_date'])][:5])
        elif degrees and any(d['fields'].get('degree_name') for d in degrees):
            result.update(status=NOT_ACCREDITED,reason='No se ha identificado un título literalmente admitido; equivalencias exigen revisión oficial.',
                          evidence=[r for d in degrees for r in ref_for(d,['degree_name'])][:5])
        elif relevant_issues(docs,['titulacion']):
            result.update(status=PENDING,reason='Documentación académica ilegible o incompleta.')
    elif kind=='license':
        relevant=[d for d in docs if d['category']=='permiso' and normalize(d['fields'].get('license_category',''))==normalize(rule['category'])]
        valid=[d for d in relevant if valid_date(d['fields'].get('expiry_date')) and valid_date(d['fields']['expiry_date'])>=cutoff]
        expired=[d for d in relevant if valid_date(d['fields'].get('expiry_date')) and valid_date(d['fields']['expiry_date'])<cutoff]
        if valid and expired:
            result.update(status=PENDING,reason='Hay documentos contradictorios sobre la caducidad del permiso; confirmar renovación y vigencia.',
                          evidence=[r for d in relevant for r in ref_for(d,['license_category','expiry_date'])][:8])
        elif valid:
            result.update(status=ACCREDITED,reason='Categoría y fecha de caducidad compatibles con la fecha de referencia (sin verificar autenticidad).',
                          evidence=ref_for(valid[0],['license_category','expiry_date']))
        elif expired and len(expired)==len(relevant):
            result.update(status=FAILED,reason='Todos los permisos de la categoría aportados constan caducados a la fecha de referencia.',
                          evidence=[r for d in expired for r in ref_for(d,['license_category','expiry_date'])][:6])
        elif relevant or relevant_issues(docs,['permiso']):
            result.update(status=PENDING,reason='Permiso sin fecha verificable o con información incompleta.')
    elif kind=='experience':
        count,refs,uncertainties=eligible_experience(docs,cutoff,rule['function_keywords'])
        result['evidence']=refs
        if count>=rule['min_days']:
            result.update(status=ACCREDITED,reason=f'{count} días únicos acreditados; mínimo {rule["min_days"]}.')
        elif uncertainties or relevant_issues(docs,['certificado_empresa','contrato','vida_laboral']):
            result.update(status=PENDING,reason=f'{count} días acreditados. '+' '.join(uncertainties[:3]))
        else:
            result.update(status=NOT_ACCREDITED,reason=f'{count} días acreditados frente a {rule["min_days"]} exigidos.')
    elif kind=='training':
        courses,issues=eligible_courses(docs,cutoff,rule['topic_keywords'])
        total=sum(c['hours'] for c in courses)
        result['evidence']=[r for c in courses for r in c['refs']][:12]
        if total>=rule['min_hours']:
            result.update(status=ACCREDITED,reason=f'{total} horas de formación acreditadas, mínimo {rule["min_hours"]}.')
        elif issues or relevant_issues(docs,['curso']):
            result.update(status=PENDING,reason=f'{total} horas; incidencias: '+'; '.join(issues[:2]))
        else:
            result.update(status=NOT_ACCREDITED,reason=f'{total} horas acreditadas, mínimo {rule["min_hours"]}.')
    return result


def score_merit(rule,docs,cutoff):
    config=rule['rule']; kind=config['kind']; max_points=rule['max_points']
    earned=0; evidence=[]; comments=[]
    if kind=='full_blocks':
        days,evidence,uncertain=eligible_experience(docs,cutoff,config['function_keywords'])
        blocks=floor(days/config['days_per_block'])
        earned=blocks*config['points_per_block']
        comments=[f'{days} días únicos / {config["days_per_block"]} días por bloque; {blocks} bloques enteros.']+uncertain
    elif kind in ('hours_steps','per_course'):
        courses,issues=eligible_courses(docs,cutoff,config['topic_keywords'],config.get('min_hours',0))
        evidence=[r for c in courses for r in c['refs']]
        comments=issues
        if kind=='hours_steps':
            total_hours=sum(c['hours'] for c in courses)
            earned=max((s['points'] for s in config['thresholds'] if total_hours>=s['min_hours']),default=0)
            comments.insert(0,f'{total_hours} horas válidas; tramo definido por la convocatoria.')
        else:
            earned=len(courses)*config['points_per_course']
            comments.insert(0,f'{len(courses)} cursos distintos que cumplen los requisitos.')
    return {'id':rule['id'],'label':rule['label'],'points':round(min(float(earned),float(max_points)),2),
        'max_points':max_points,'reason':' '.join(comments),'evidence':evidence[:24],
        'pending_review':bool([x for x in comments if 'contradictor' in x or 'sin acreditar' in x or 'incomplet' in x])}


def evaluate_case(config,documents):
    cutoff=valid_date(config['cutoff_date'])
    if not cutoff: raise ValueError('Fecha de referencia no configurada.')
    requirements=[evaluate_requirement(r,documents,cutoff) for r in config['requirements']]
    merits=[score_merit(m,documents,cutoff) for m in config['merits']]
    total=round(sum(m['points'] for m in merits),2)
    if total>45: raise ValueError('Error del motor: excedido el máximo de 45 puntos.')
    document_issues=[{'doc_id':d['doc_id'],'filename':d['filename'],'message':issue} for d in documents for issue in d['issues']]
    return {'requirements':requirements,'merits':merits,'total':total,'documents':documents,
            'document_issues':document_issues,'demonstration':any(d['mode']=='demostracion_sin_ia' for d in documents),
            'contains_fixtures':any(d['fixture'] for d in documents)}


def effective_result(analysis,overrides):
    """Resultados sin cambiar el cálculo de base; correcciones humanas identificadas."""
    import copy
    result=copy.deepcopy(analysis['payload'])
    for req in result['requirements']:
        entry=overrides.get(('requirement',req['id']))
        if entry:
            if entry.get('status') not in STATES: raise ValueError('Estado de requisito inválido.')
            req['status']=entry['status'];req['manual']=True;req['reason']='Revisión humana: '+entry.get('reason','')
    for merit in result['merits']:
        entry=overrides.get(('merit',merit['id']))
        if entry:
            score=entry['points']
            if type(score) not in (float,int) or score<0 or score>merit['max_points']:
                raise ValueError('Puntuación manual fuera de límites.')
            merit['points']=round(score,2);merit['manual']=True;merit['reason']='Corrección humana: '+entry.get('reason','')
    result['total']=round(sum(m['points'] for m in result['merits']),2)
    if result['total']>45:raise ValueError('Total inválido.')
    return result
