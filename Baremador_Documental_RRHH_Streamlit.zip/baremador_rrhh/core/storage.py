"""SQLite local, expedientes segregados por convocatoria y candidatura.
Persistencia orientada a prototipo, no a producción multicliente.
"""
from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
from io import BytesIO
import json
import os
from pathlib import Path
import sqlite3
from uuid import uuid4

from docx import Document

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = ROOT / 'data' / 'runtime.sqlite'


def now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def json_dumps(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def connect(db_path=None):
    path = Path(db_path or os.getenv('APP_DB_PATH', str(DEFAULT_DB)))
    path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(str(path), timeout=20)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('PRAGMA busy_timeout=20000')
    return db


def initialize(db_path=None):
    from core.config import validate_config
    db = connect(db_path)
    with db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS vacancies(code TEXT PRIMARY KEY, title TEXT NOT NULL, config_json TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS candidates(vacancy TEXT NOT NULL, candidate TEXT NOT NULL, label TEXT NOT NULL,
            PRIMARY KEY(vacancy,candidate), FOREIGN KEY(vacancy) REFERENCES vacancies(code));
        CREATE TABLE IF NOT EXISTS documents(id TEXT PRIMARY KEY, vacancy TEXT NOT NULL, candidate TEXT NOT NULL,
            filename TEXT NOT NULL, category TEXT NOT NULL, mimetype TEXT NOT NULL, content BLOB NOT NULL,
            sha256 TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, fixture INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL, FOREIGN KEY(vacancy,candidate) REFERENCES candidates(vacancy,candidate));
        CREATE TABLE IF NOT EXISTS analyses(id TEXT PRIMARY KEY, vacancy TEXT NOT NULL, candidate TEXT NOT NULL,
            fingerprint TEXT NOT NULL, payload TEXT NOT NULL, created_at TEXT NOT NULL,
            UNIQUE(vacancy,candidate,fingerprint));
        CREATE TABLE IF NOT EXISTS reviews(analysis_id TEXT NOT NULL, kind TEXT NOT NULL, item_id TEXT NOT NULL,
            value_json TEXT NOT NULL, reviewer TEXT NOT NULL, reason TEXT NOT NULL, changed_at TEXT NOT NULL,
            PRIMARY KEY(analysis_id,kind,item_id));
        CREATE TABLE IF NOT EXISTS validations(analysis_id TEXT PRIMARY KEY, reviewer TEXT NOT NULL,
            changed_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS audit(id TEXT PRIMARY KEY, vacancy TEXT NOT NULL, candidate TEXT,
            action TEXT NOT NULL, actor TEXT NOT NULL, before_json TEXT, after_json TEXT,
            reason TEXT NOT NULL, changed_at TEXT NOT NULL);
        ''')
        if db.execute('SELECT COUNT(*) FROM vacancies').fetchone()[0] == 0:
            configs = json.loads((ROOT / 'data' / 'convocatorias.json').read_text(encoding='utf-8'))
            for config in configs:
                validate_config(config)
                db.execute('INSERT INTO vacancies VALUES(?,?,?,1)', (config['code'],config['title'],json_dumps(config)))
            for person in json.loads((ROOT / 'data' / 'candidatos.json').read_text(encoding='utf-8')):
                db.execute('INSERT INTO candidates VALUES(?,?,?)', (person['vacancy'],person['id'],person['label']))
            for fixture in json.loads((ROOT / 'data' / 'documentos_demo.json').read_text(encoding='utf-8')):
                document = Document()
                for line in fixture['lines']:
                    document.add_paragraph(line)
                b = BytesIO()
                document.save(b)
                content = b.getvalue()
                db.execute('''INSERT INTO documents(id,vacancy,candidate,filename,category,mimetype,content,sha256,active,fixture,created_at)
                  VALUES(?,?,?,?,?,?,?,?,1,1,?)''', (uuid4().hex,fixture['vacancy'],fixture['candidate'],fixture['name'],fixture['category'],
                  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',content,sha256(content).hexdigest(),now()))
    db.close()


def vacancies(db_path=None):
    with connect(db_path) as db:
        return [dict(r) for r in db.execute('SELECT code,title,version FROM vacancies ORDER BY code')]


def get_config(code, db_path=None):
    with connect(db_path) as db:
        r = db.execute('SELECT config_json,version FROM vacancies WHERE code=?',(code,)).fetchone()
        if not r: raise ValueError('Convocatoria no encontrada')
        d = json.loads(r['config_json']); d['_version'] = r['version']
        return d


def list_candidates(vacancy, db_path=None):
    with connect(db_path) as db:
        return [dict(r) for r in db.execute('SELECT candidate,label FROM candidates WHERE vacancy=? ORDER BY candidate',(vacancy,))]


def list_documents(vacancy, candidate, db_path=None):
    with connect(db_path) as db:
        return [dict(r) for r in db.execute('''SELECT id,filename,category,mimetype,sha256,fixture,created_at FROM documents
            WHERE vacancy=? AND candidate=? AND active=1 ORDER BY created_at,id''',(vacancy,candidate))]


def get_document(doc_id, vacancy, candidate, db_path=None):
    with connect(db_path) as db:
        row = db.execute('''SELECT * FROM documents WHERE id=? AND vacancy=? AND candidate=? AND active=1''',(doc_id,vacancy,candidate)).fetchone()
        return dict(row) if row else None


def add_document(vacancy, candidate, filename, category, mimetype, content, actor='demo', db_path=None):
    if not content or len(content) > 10*1024*1024:
        raise ValueError('El archivo está vacío o supera 10 MB.')
    filename = Path(str(filename).replace('\\','/')).name[:140]
    if not filename: raise ValueError('Nombre de archivo no válido')
    digest = sha256(content).hexdigest()
    with connect(db_path) as db:
        existing = db.execute('''SELECT id,sha256 FROM documents WHERE vacancy=? AND candidate=? AND filename=? AND active=1''',
            (vacancy,candidate,filename)).fetchone()
        if existing and existing['sha256'] == digest:
            return existing['id']
        if existing:
            db.execute('UPDATE documents SET active=0 WHERE id=?',(existing['id'],))
        docid=uuid4().hex
        db.execute('''INSERT INTO documents VALUES(?,?,?,?,?,?,?,?,1,0,?)''',
            (docid,vacancy,candidate,filename,category,mimetype,content,digest,now()))
        _audit(db,vacancy,candidate,'document_uploaded',actor,
               dict(existing) if existing else None,{'id':docid,'filename':filename,'sha256':digest},
               'Nueva versión del archivo' if existing else 'Documento añadido')
        return docid


def get_fingerprint(vacancy, candidate, db_path=None):
    config=get_config(vacancy,db_path)
    docs=list_documents(vacancy,candidate,db_path)
    return sha256(json_dumps({'config_version':config['_version'], 'docs':[(d['id'],d['sha256'],d['category']) for d in docs],
        'engine_version':'v1.2'}).encode('utf-8')).hexdigest()


def save_analysis(vacancy,candidate,payload,actor='motor',db_path=None):
    fingerprint=get_fingerprint(vacancy,candidate,db_path)
    with connect(db_path) as db:
        existing=db.execute('SELECT id FROM analyses WHERE vacancy=? AND candidate=? AND fingerprint=?',(vacancy,candidate,fingerprint)).fetchone()
        if existing: return existing['id']
        ident=uuid4().hex
        db.execute('INSERT INTO analyses VALUES(?,?,?,?,?,?)',(ident,vacancy,candidate,fingerprint,json_dumps(payload),now()))
        _audit(db,vacancy,candidate,'analysis_executed',actor,None,{'analysis_id':ident,'fingerprint':fingerprint},'Evaluación provisional')
        return ident


def get_analysis(vacancy,candidate,db_path=None):
    fingerprint=get_fingerprint(vacancy,candidate,db_path)
    with connect(db_path) as db:
        row=db.execute('SELECT * FROM analyses WHERE vacancy=? AND candidate=? AND fingerprint=?',(vacancy,candidate,fingerprint)).fetchone()
        if not row:return None
        ret=dict(row)
        ret['payload']=json.loads(ret['payload'])
        return ret


def previous_reviews(vacancy,candidate,db_path=None):
    """Solo consulta de antecedentes; NO los aplica a una nueva evidencia."""
    with connect(db_path) as db:
        return [dict(r) for r in db.execute('''SELECT r.*,a.created_at AS analysis_date FROM reviews r JOIN analyses a ON a.id=r.analysis_id
            WHERE a.vacancy=? AND a.candidate=? ORDER BY r.changed_at DESC LIMIT 100''',(vacancy,candidate))]


def get_reviews(analysis_id,db_path=None):
    with connect(db_path) as db:
        return {(r['kind'],r['item_id']):json.loads(r['value_json']) for r in db.execute('SELECT * FROM reviews WHERE analysis_id=?',(analysis_id,))}


def save_review(vacancy,candidate,analysis_id,kind,item_id,value,reviewer,reason,db_path=None):
    if not reviewer.strip() or not reason.strip(): raise ValueError('Usuario y justificación obligatorios.')
    current_fingerprint=get_fingerprint(vacancy,candidate,db_path)
    with connect(db_path) as db:
        row=db.execute('SELECT id,fingerprint,payload FROM analyses WHERE id=? AND vacancy=? AND candidate=?',(analysis_id,vacancy,candidate)).fetchone()
        if not row or row['fingerprint']!=current_fingerprint:
            raise ValueError('El análisis ya no coincide con la versión vigente del expediente.')
        from core.evaluation import STATES
        payload=json.loads(row['payload'])
        if kind=='requirement':
            if item_id not in [r['id'] for r in payload['requirements']] or value.get('status') not in STATES:
                raise ValueError('Requisito o estado no válido.')
        elif kind=='merit':
            merit=next((m for m in payload['merits'] if m['id']==item_id),None)
            points=value.get('points')
            if merit is None or type(points) not in (float,int) or not 0<=points<=merit['max_points']:
                raise ValueError('Mérito o puntuación fuera del baremo.')
        else:raise ValueError('Tipo de revisión desconocido.')
        prior=db.execute('SELECT value_json FROM reviews WHERE analysis_id=? AND kind=? AND item_id=?',(analysis_id,kind,item_id)).fetchone()
        before=json.loads(prior['value_json']) if prior else None
        db.execute('''INSERT INTO reviews VALUES(?,?,?,?,?,?,?) ON CONFLICT(analysis_id,kind,item_id) DO UPDATE SET
            value_json=excluded.value_json,reviewer=excluded.reviewer,reason=excluded.reason,changed_at=excluded.changed_at''',
            (analysis_id,kind,item_id,json_dumps(value),reviewer,reason,now()))
        db.execute('DELETE FROM validations WHERE analysis_id=?',(analysis_id,))
        _audit(db,vacancy,candidate,'manual_review',reviewer,{'item_type':kind,'item_id':item_id,'value':before},
            {'item_type':kind,'item_id':item_id,'value':value},reason)


def is_validated(analysis_id,db_path=None):
    with connect(db_path) as db:
        return db.execute('SELECT 1 FROM validations WHERE analysis_id=?',(analysis_id,)).fetchone() is not None


def validate_eligibility(vacancy,candidate,analysis_id,reviewer,db_path=None):
    if not reviewer.strip():raise ValueError('Indique el usuario responsable.')
    current_fingerprint=get_fingerprint(vacancy,candidate,db_path)
    with connect(db_path) as db:
        row=db.execute('SELECT id,fingerprint,payload FROM analyses WHERE id=? AND vacancy=? AND candidate=?',(analysis_id,vacancy,candidate)).fetchone()
        if not row or row['fingerprint']!=current_fingerprint:
            raise ValueError('Análisis inexistente o desactualizado para la candidatura.')
        from core.evaluation import ACCREDITED,effective_result
        reviews={(r['kind'],r['item_id']):json.loads(r['value_json']) for r in db.execute(
            'SELECT * FROM reviews WHERE analysis_id=?',(analysis_id,))}
        result=effective_result({'payload':json.loads(row['payload'])},reviews)
        if not all(r['status']==ACCREDITED for r in result['requirements']):
            raise ValueError('Solo puede validarse un expediente con todos los requisitos acreditados.')
        old=db.execute('SELECT reviewer,changed_at FROM validations WHERE analysis_id=?',(analysis_id,)).fetchone()
        db.execute('INSERT OR REPLACE INTO validations VALUES(?,?,?)',(analysis_id,reviewer,now()))
        _audit(db,vacancy,candidate,'eligibility_validated',reviewer,dict(old) if old else None,
            {'analysis_id':analysis_id,'validated':True},'Revisión humana de todos los requisitos')


def save_config(vacancy,config,actor,db_path=None):
    from core.config import validate_config
    validate_config(config)
    if config['code'] != vacancy: raise ValueError('No se puede modificar el código de una convocatoria existente.')
    if not actor.strip():raise ValueError('Usuario obligatorio.')
    with connect(db_path) as db:
        row=db.execute('SELECT config_json FROM vacancies WHERE code=?',(vacancy,)).fetchone()
        if not row:raise ValueError('Convocatoria no encontrada.')
        old=json.loads(row['config_json'])
        config={k:v for k,v in config.items() if not k.startswith('_')}
        if old==config:return
        db.execute('UPDATE vacancies SET title=?,config_json=?,version=version+1 WHERE code=?',
            (config['title'],json_dumps(config),vacancy))
        _audit(db,vacancy,None,'config_changed',actor,old,config,'Modificación de las bases ficticias')


def audit_list(vacancy,db_path=None):
    with connect(db_path) as db:
        return [dict(r) for r in db.execute('SELECT * FROM audit WHERE vacancy=? ORDER BY changed_at DESC,id DESC',(vacancy,))]


def _audit(db,vacancy,candidate,action,actor,before,after,reason):
    db.execute('''INSERT INTO audit VALUES(?,?,?,?,?,?,?,?,?)''',
        (uuid4().hex,vacancy,candidate,action,actor,json_dumps(before),json_dumps(after),reason,now()))
