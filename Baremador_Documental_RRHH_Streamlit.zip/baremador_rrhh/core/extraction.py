"""Lectura real de documentos y extracción de campos (sin decidir elegibilidad)."""
from __future__ import annotations

from io import BytesIO
import json
import re
import unicodedata

from docx import Document
from PIL import Image, UnidentifiedImageError
from pypdf import PdfReader

MAX_PAGES = 30
MAX_CHARS = 50000
ALLOWED = {'.pdf': 'application/pdf', '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
           '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png'}
FIELDS = {
    'titulacion': {'nombre':'degree_name','nivel':'level','emisor':'issuer','institucion':'issuer','fecha':'issue_date'},
    'permiso': {'categoria':'license_category','vencimiento':'expiry_date','caducidad':'expiry_date'},
    'certificado_empresa': {'empresa':'company','puesto':'role','funciones':'functions','inicio':'start_date','fin':'end_date'},
    'contrato': {'empresa':'company','puesto':'role','funciones':'functions','inicio':'start_date','fin':'end_date'},
    'vida_laboral': {'empresa':'company','puesto':'role','funciones':'functions','inicio':'start_date','fin':'end_date'},
    'curso': {'nombre':'course_name','tema':'topic','horas':'hours','entidad':'issuer','emisor':'issuer','fecha':'issue_date'},
    'otro': {},
}


def normalize(text):
    return ''.join(c for c in unicodedata.normalize('NFKD',str(text).lower()) if not unicodedata.combining(c)).strip()


def validate_upload(filename, content):
    from pathlib import Path
    ext = Path(filename.lower()).suffix
    if ext not in ALLOWED: raise ValueError('Formato no admitido. Use PDF, DOCX, JPG o PNG.')
    if not content or len(content) > 10*1024*1024: raise ValueError('El documento debe ocupar entre 1 byte y 10 MB.')
    if ext == '.pdf' and not content.startswith(b'%PDF'): raise ValueError('Contenido PDF no válido.')
    if ext == '.docx' and not content.startswith(b'PK') : raise ValueError('DOCX no válido.')
    if ext in ('.jpg','.jpeg') and not content.startswith(b'\xff\xd8'): raise ValueError('JPG no válido.')
    if ext == '.png' and not content.startswith(b'\x89PNG\r\n\x1a\n'): raise ValueError('PNG no válido.')
    return ALLOWED[ext]


def _ocr(image):
    import pytesseract
    try:
        return pytesseract.image_to_string(image,lang='spa+eng')
    except pytesseract.TesseractError:
        return pytesseract.image_to_string(image,lang='eng')


def read_document(content, filename):
    """Devuelve páginas reales, incidencias de lectura y fuente OCR cuando procede."""
    validate_upload(filename,content)
    ext = filename.lower().rsplit('.',1)[-1]
    problems=[]
    pages=[]
    try:
        if ext == 'pdf':
            reader=PdfReader(BytesIO(content), strict=False)
            if len(reader.pages) > MAX_PAGES:
                problems.append(f'Solo se analizaron las primeras {MAX_PAGES} páginas.')
            for i,page in enumerate(reader.pages[:MAX_PAGES],1):
                txt=page.extract_text() or ''
                if not txt.strip():
                    try:
                        import fitz
                        pdf=fitz.open(stream=content,filetype='pdf')
                        pix=pdf[i-1].get_pixmap(matrix=fitz.Matrix(1.3,1.3))
                        img=Image.open(BytesIO(pix.tobytes('png')))
                        txt=_ocr(img)
                        problems.append(f'Página {i}: OCR, posible pérdida de precisión.')
                        pdf.close()
                    except Exception as exc:
                        problems.append(f'Página {i}: OCR no disponible ({type(exc).__name__}).')
                pages.append({'page':i,'text':txt[:MAX_CHARS]})
        elif ext == 'docx':
            doc=Document(BytesIO(content))
            paragraphs=[p.text for p in doc.paragraphs if p.text.strip()]
            for table in doc.tables:
                for row in table.rows:
                    paragraphs.append(' | '.join(c.text for c in row.cells))
            pages=[{'page':1,'text':'\n'.join(paragraphs)[:MAX_CHARS]}]
        else:
            Image.MAX_IMAGE_PIXELS = 20_000_000
            img=Image.open(BytesIO(content))
            img.verify()
            img=Image.open(BytesIO(content)).convert('RGB')
            pages=[{'page':1,'text':_ocr(img)[:MAX_CHARS]}]
            problems.append('Imagen interpretada con OCR; verificar manualmente.')
    except (UnidentifiedImageError,ValueError,RuntimeError) as exc:
        problems.append(f'Documento dañado o no interpretable ({type(exc).__name__}).')
    except Exception as exc:
        problems.append(f'Error de extracción: {type(exc).__name__}.')
    if not pages or not any(p['text'].strip() for p in pages):
        problems.append('Documento vacío, ilegible o sin texto extraíble.')
    return pages,problems


def local_fields(pages,category):
    """Extracción conservadora para formularios con 'Etiqueta: valor'."""
    mapping=FIELDS.get(category,{})
    result={}
    evidences=[]
    for page in pages:
        for line in page['text'].splitlines():
            match=re.match(r'^\s*([^:]{1,40})\s*:\s*(.+?)\s*$',line)
            if not match:continue
            field=mapping.get(normalize(match.group(1)))
            if not field:continue
            value=match.group(2).strip()
            if field in ('hours',):
                found=re.search(r'\d+',value)
                if not found:continue
                value=int(found.group())
            if field not in result:
                result[field]=value
                evidences.append({'field':field,'page':page['page'],'quote':line.strip()[:350]})
            elif normalize(result[field]) != normalize(value):
                evidences.append({'field':field,'page':page['page'],'quote':line.strip()[:350],'conflict':True})
    return result,evidences


def _api_fields(pages,category,api_key,model):
    from openai import OpenAI
    text='\n'.join(f"[Página {p['page']}] {p['text']}" for p in pages)[:30000]
    allowed=list(set(FIELDS.get(category,{}).values()))
    if not allowed: return {},[]
    prompt=("Extrae únicamente datos explícitos del documento de candidatura. No supongas, no calcules elegibilidad ni puntuaciones. "
        "Devuelve un objeto JSON con clave 'fields', que contenga SOLO campos de esta lista: " + ', '.join(allowed) + ". "
        "Todos los valores serán texto salvo 'hours' (entero). Fechas YYYY-MM-DD cuando sean inequívocas. "
        "Si falta un campo omítelo. No devuelvas información personal irrelevante.\n\n" + text)
    response=OpenAI(api_key=api_key,timeout=25,max_retries=1).chat.completions.create(
        model=model,temperature=0,response_format={'type':'json_object'},messages=[
            {'role':'system','content':'Eres extractor documental. Devuelve JSON estricto, nunca inventes datos.'},
            {'role':'user','content':prompt}])
    raw=json.loads(response.choices[0].message.content or '{}')
    fields=raw.get('fields',{})
    if not isinstance(fields,dict): return {},[]
    verified={}; refs=[]
    for field,value in fields.items():
        if field not in allowed or value is None:continue
        val=str(value).strip()
        if not val:continue
        # Ningún dato de IA se acepta si no aparece literalmente en alguna página.
        found_page=next((p for p in pages if normalize(val) in normalize(p['text'])),None)
        if not found_page:continue
        if field=='hours':
            if not val.isdigit():continue
            value=int(val)
        verified[field]=value
        line=next((l for l in found_page['text'].splitlines() if normalize(val) in normalize(l)),val)
        refs.append({'field':field,'page':found_page['page'],'quote':line.strip()[:350]})
    return verified,refs


def interpret_document(document,api_key=None,model='gpt-4o-mini'):
    pages,issues=read_document(document['content'],document['filename'])
    fields,refs=local_fields(pages,document['category'])
    mode='demostracion_sin_ia'
    if api_key and pages and any(p['text'].strip() for p in pages):
        try:
            predicted,refs_model=_api_fields(pages,document['category'],api_key,model)
            # Solo campos con confirmación textual: mantén los locales en ausencia de un campo de IA.
            fields.update(predicted)
            refs=[x for x in refs if x['field'] not in predicted]+refs_model
            mode='ia_con_comprobacion_textual'
        except Exception as exc:
            issues.append(f'IA no disponible ({type(exc).__name__}); se usó extracción local de demostración.')
    if not fields:
        issues.append('No se identificaron campos estructurados; revisión manual necesaria.')
    if document['category'] in ('certificado_empresa','contrato','vida_laboral'):
        if fields.get('start_date') and fields.get('end_date') and str(fields['start_date'])>str(fields['end_date']):
            issues.append('Fechas contradictorias: inicio posterior al fin.')
    return {'doc_id':document['id'],'filename':document['filename'],'category':document['category'],
        'fixture':bool(document['fixture']),'mode':mode,'fields':fields,'evidence':refs,
        'issues':issues,'pages':len(pages)}
