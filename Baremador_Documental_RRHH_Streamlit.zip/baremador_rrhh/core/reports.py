"""Exportadores PDF/CSV/Excel, con estado, fecha y referencias de prueba."""
from __future__ import annotations
from datetime import datetime, timezone
from html import escape
from io import BytesIO
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether


def timestamp():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def _safe(value):
    return escape(str(value or '')).replace('\n',' ')


def pdf_candidate(result,config):
    """PDF descargable con criterio, justificación, evidencia y carácter de provisionalidad."""
    target=BytesIO()
    doc=SimpleDocTemplate(target,pagesize=(21*cm,29.7*cm),rightMargin=1.7*cm,leftMargin=1.7*cm,
                          topMargin=1.8*cm,bottomMargin=1.8*cm)
    styles=getSampleStyleSheet()
    styles.add(ParagraphStyle(name='InformeTitulo',parent=styles['Title'],fontSize=16,leading=20,textColor=colors.HexColor('#10375c')))
    styles.add(ParagraphStyle(name='InformeSmall',parent=styles['BodyText'],fontSize=8.5,leading=12,spaceAfter=5))
    styles.add(ParagraphStyle(name='InformeSec',parent=styles['Heading2'],fontSize=12,leading=16,spaceBefore=13))
    story=[Paragraph('INFORME INDIVIDUAL DE CANDIDATURA',styles['InformeTitulo']),
           Paragraph(f"Convocatoria: {_safe(config['code'])} - {_safe(config['title'])}",styles['InformeSmall']),
           Paragraph(f"Candidatura: {_safe(result['candidate'])} | Fecha UTC: {_safe(timestamp())}",styles['InformeSmall']),
           Paragraph(f"Estado: <b>{_safe(result['status'])}</b>",styles['InformeSmall']),
           Paragraph('<b>Datos y procesos ficticios. Este informe no es una decisión administrativa.</b>',styles['InformeSmall']),
           Paragraph(f"Puntuación: <b>{result['result']['total']:.2f} / 45</b>",styles['InformeSmall']),
           Paragraph('Requisitos obligatorios',styles['InformeSec'])]
    for req in result['result']['requirements']:
        story.append(Paragraph(f"<b>{_safe(req['label'])} — {_safe(req['status'])}</b>",styles['InformeSmall']))
        story.append(Paragraph(_safe(req['reason']),styles['InformeSmall']))
        for ref in req['evidence'][:5]:
            story.append(Paragraph(f"Prueba: {_safe(ref['filename'])}, pág. {_safe(ref['page'])}: «{_safe(ref['quote'])}»",styles['InformeSmall']))
    story.append(Paragraph('Baremo de méritos',styles['InformeSec']))
    for merit in result['result']['merits']:
        story.append(Paragraph(f"<b>{_safe(merit['label'])}: {merit['points']:.2f} / {merit['max_points']}</b>",styles['InformeSmall']))
        story.append(Paragraph(_safe(merit['reason']),styles['InformeSmall']))
        for ref in merit['evidence'][:6]:
            story.append(Paragraph(f"Prueba: {_safe(ref['filename'])}, pág. {_safe(ref['page'])}: «{_safe(ref['quote'])}»",styles['InformeSmall']))
    story.append(Paragraph('Incidencias y limitaciones',styles['InformeSec']))
    for issue in result['result']['document_issues']:
        story.append(Paragraph(f"{_safe(issue['filename'])}: {_safe(issue['message'])}",styles['InformeSmall']))
    if not result['result']['document_issues']:
        story.append(Paragraph('Sin incidencias detectadas automáticamente.',styles['InformeSmall']))
    story.append(Spacer(1,10))
    story.append(Paragraph('La extracción documental no acredita por sí misma autenticidad ni equivalencia académica. '
        'Las puntuaciones son provisionales salvo revisión humana expresa.',styles['InformeSmall']))
    doc.build(story)
    return target.getvalue()


def csv_bytes(rows):
    return pd.DataFrame(rows).to_csv(index=False,encoding='utf-8-sig').encode('utf-8-sig')


def excel_bytes(sheets):
    b=BytesIO()
    with pd.ExcelWriter(b,engine='openpyxl') as writer:
        for name,rows in sheets.items():
            pd.DataFrame(rows).to_excel(writer,sheet_name=name[:31],index=False)
    return b.getvalue()


def export_rows(vacancy,classification,audit):
    base={'Convocatoria':vacancy,'Generado UTC':timestamp()}
    ranked=[dict(base,**r) for r in classification]
    incidents=[]
    from core import storage
    from core.service import case_result
    for c in storage.list_candidates(vacancy):
        case=case_result(vacancy,c['candidate'])
        if not case:continue
        for event in case['result']['document_issues']:
            incidents.append(dict(base,Candidatura=c['candidate'],Documento=event['filename'],Incidencia=event['message']))
        for req in case['result']['requirements']:
            if req['status']!='Acreditado':
                incidents.append(dict(base,Candidatura=c['candidate'],Documento='Requisito '+req['id'],Incidencia=req['reason']))
    logs=[dict(base,**r) for r in audit]
    return {'Clasificacion':ranked,'Incidencias':incidents,'Auditoria':logs}
