"""Validación estricta de bases ficticias; nunca generar baremos por IA."""
from __future__ import annotations

from datetime import date


class ConfigurationError(ValueError):
    pass


def validate_config(config: dict) -> None:
    problems = []
    try:
        date.fromisoformat(config['cutoff_date'])
    except (KeyError, ValueError, TypeError):
        problems.append('Fecha de referencia no válida (AAAA-MM-DD).')
    if not str(config.get('code', '')).strip():
        problems.append('Falta el código de convocatoria.')
    if not str(config.get('title', '')).strip():
        problems.append('Falta la denominación.')
    if config.get('max_total') != 45:
        problems.append('En este prototipo el máximo global debe ser 45.')
    merits = config.get('merits', [])
    reqs = config.get('requirements', [])
    if not isinstance(merits, list) or not merits or not isinstance(reqs, list) or not reqs:
        problems.append('Configure requisitos y méritos no vacíos.')
        raise ConfigurationError(' '.join(problems))
    for section, items in [('requisitos', reqs), ('méritos', merits)]:
        ids = [str(item.get('id', '')) for item in items]
        if len(ids) != len(set(ids)) or not all(ids):
            problems.append(f'IDs de {section} ausentes o duplicados.')
    total = 0
    for merit in merits:
        name = merit.get('id', '?')
        p = merit.get('max_points')
        if type(p) is not int or p <= 0 or p % 5:
            problems.append(f'{name}: máximo entero positivo en múltiplos de 5.')
            continue
        total += p
        rule = merit.get('rule') or {}
        kind = rule.get('kind')
        if merit.get('type') not in ('course', 'experience'):
            problems.append(f'{name}: tipo de mérito no implementado.')
        if kind == 'full_blocks':
            if not isinstance(rule.get('days_per_block'), int) or rule['days_per_block'] <= 0:
                problems.append(f'{name}: días por bloque no definidos.')
            if not isinstance(rule.get('points_per_block'), (int, float)) or rule['points_per_block'] <= 0:
                problems.append(f'{name}: puntos por bloque no definidos.')
            if rule.get('rounding') != 'floor' or not rule.get('function_keywords'):
                problems.append(f'{name}: redondeo o funciones de referencia no definidos.')
        elif kind == 'hours_steps':
            steps = rule.get('thresholds', [])
            if not rule.get('topic_keywords') or not steps or any(
                not isinstance(s.get('min_hours'), int) or s['min_hours'] < 0 or
                not isinstance(s.get('points'), (int, float)) or s['points'] < 0 or s['points'] > p
                for s in steps
            ):
                problems.append(f'{name}: tabla de tramos/temas inválida.')
            elif sorted(s['min_hours'] for s in steps) != [s['min_hours'] for s in steps]:
                problems.append(f'{name}: tramos no ordenados.')
        elif kind == 'per_course':
            if not rule.get('topic_keywords') or not isinstance(rule.get('min_hours'), int) or rule['min_hours'] < 0 or not isinstance(rule.get('points_per_course'), (int, float)) or rule['points_per_course'] <= 0:
                problems.append(f'{name}: reglas de curso incompletas.')
        else:
            problems.append(f'{name}: regla desconocida ({kind}).')
    for req in reqs:
        kind = req.get('type')
        if kind == 'degree' and not req.get('allowed_titles'):
            problems.append(f"{req.get('id')}: títulos admitidos no definidos.")
        elif kind == 'license' and not req.get('category'):
            problems.append(f"{req.get('id')}: categoría no definida.")
        elif kind == 'experience' and (not isinstance(req.get('min_days'), int) or req['min_days'] <= 0 or not req.get('function_keywords')):
            problems.append(f"{req.get('id')}: experiencia mínima o funciones no definidas.")
        elif kind == 'training' and (not isinstance(req.get('min_hours'), int) or req['min_hours'] <= 0 or not req.get('topic_keywords')):
            problems.append(f"{req.get('id')}: formación mínima o temática no definida.")
        elif kind not in ('degree', 'license', 'experience', 'training'):
            problems.append(f"{req.get('id')}: tipo de requisito desconocido.")
    if total > 45:
        problems.append(f'La suma de baremos es {total} y supera 45.')
    tie_breakers=config.get('tie_breakers', [])
    if not isinstance(tie_breakers,list):
        problems.append('Los desempates deben proporcionarse como una lista.')
    else:
        merit_ids={m.get('id') for m in merits}
        selected=[]
        for item in tie_breakers:
            if not isinstance(item,dict) or item.get('merit_id') not in merit_ids or item.get('direction') not in ('asc','desc'):
                problems.append('Desempate inválido: indique mérito existente y dirección asc o desc.')
            else:
                selected.append(item['merit_id'])
        if len(selected)!=len(set(selected)):
            problems.append('No repita criterios de desempate.')
    if problems:
        raise ConfigurationError(' '.join(problems))
