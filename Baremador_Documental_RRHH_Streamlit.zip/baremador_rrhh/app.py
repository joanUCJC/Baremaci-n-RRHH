"""Aplicación académica Streamlit: revisión documental y baremación asistida."""
from __future__ import annotations

import copy
import json
from pathlib import Path

import pandas as pd
import streamlit as st

from core import storage
from core.config import validate_config, ConfigurationError
from core.evaluation import ACCREDITED, FAILED, NOT_ACCREDITED, PENDING, STATES
from core.extraction import validate_upload
from core.reports import pdf_candidate, csv_bytes, excel_bytes, export_rows
from core.service import case_result, classification, run_analysis

st.set_page_config(page_title='Baremador documental | Demo RRHH',page_icon='📑',layout='wide',initial_sidebar_state='expanded')
st.markdown('''<style>
.block-container {padding-top:1.6rem; max-width:1300px}
h1 {color:#10375c;letter-spacing:-.7px}
h2,h3 {color:#174c70}
[data-testid="stMetric"] {background:#f4f7fb; border:1px solid #dce5ee; border-radius:12px; padding:12px}
</style>''',unsafe_allow_html=True)


def secret(section,key,default=None):
    try:return st.secrets[section].get(key,default)
    except (KeyError,FileNotFoundError,OSError):return default
    except Exception:return default


def controlled_actor():
    pwd=secret('auth','reviewer_password')
    if pwd and str(pwd).startswith('REEMPLAZAR_'):
        pwd=None
    if pwd:
        from hmac import compare_digest
        if not st.session_state.get('auth_ok'):
            st.title('Acceso a demostración académica')
            guess=st.text_input('Contraseña del prototipo',type='password')
            if st.button('Acceder',type='primary'):
                if compare_digest(str(guess),str(pwd)):
                    st.session_state['auth_ok']=True;st.rerun()
                else:st.error('Credenciales no válidas.')
            st.stop()
    else:
        st.sidebar.warning('Modo público de demostración: sin autenticación. SOLO datos ficticios.')
    actor=st.sidebar.text_input('Identificador del técnico',value='tecnico_demo',max_chars=60,
        help='Se conserva en el historial de la demo. No equivale a una identidad autenticada.')
    if not actor.strip():
        st.warning('Introduzca un identificador de revisión.');st.stop()
    return actor.strip()


def api_details():
    api_key=secret('openai','api_key')
    if api_key and str(api_key).startswith('REEMPLAZAR_'):api_key=None
    return api_key,secret('openai','model','gpt-4o-mini')


def badge(status):
    display={ACCREDITED:'🟢',NOT_ACCREDITED:'⚪',FAILED:'🔴',PENDING:'🟠'}
    return f'{display.get(status,"🔵")} {status}'


def show_evidence(evidence):
    if not evidence:st.caption('Sin fragmentos de evidencia registrados.')
    for ref in evidence[:12]:
        st.caption(f"📎 {ref['filename']} · pág. {ref['page']} — «{ref['quote']}»")


def choose_candidate(vacancy,form_key='case'):
    people=storage.list_candidates(vacancy)
    if not people:st.warning('Esta convocatoria no contiene candidaturas.');st.stop()
    ids=[c['candidate'] for c in people]
    return st.selectbox('Seleccionar candidatura',ids,key=f'{form_key}_{vacancy}',
        format_func=lambda x:next((p['label'] for p in people if p['candidate']==x),x))


def list_document_controls(vacancy,candidate):
    st.subheader('Documentación del expediente')
    docs=storage.list_documents(vacancy,candidate)
    if not docs:st.info('Todavía no se han incorporado documentos.')
    for item in docs:
        col1,col2,col3=st.columns([3,2,1.2],vertical_alignment='center')
        col1.markdown(f"**{item['filename']}**")
        col2.caption(f"{item['category']} · {'Ficticio' if item['fixture'] else 'Aportado'}")
        document=storage.get_document(item['id'],vacancy,candidate)
        col3.download_button('Ver / descargar',data=document['content'],file_name=item['filename'],
                             mime=item['mimetype'],key='dl_'+item['id'])


def doc_upload(vacancy,candidate,actor):
    with st.expander('➕ Incorporar o actualizar documentación',expanded=False):
        st.caption('Máximo 10 MB por archivo. No utilice documentos reales ni datos personales.')
        category_labels={
            'titulacion':'Título / certificado académico','permiso':'Permiso de conducir',
            'certificado_empresa':'Certificado de empresa','contrato':'Contrato',
            'vida_laboral':'Vida laboral','curso':'Curso / certificado de formación','otro':'Otros'}
        with st.form('upload_'+candidate,clear_on_submit=True):
            cat=st.selectbox('Tipo de acreditación',list(category_labels),format_func=lambda x:category_labels[x])
            uploads=st.file_uploader('PDF, DOCX, JPG o PNG',type=['pdf','docx','jpg','jpeg','png'],accept_multiple_files=True)
            save=st.form_submit_button('Guardar archivos',type='primary')
        if save:
            if not uploads:st.error('Seleccione al menos un documento.')
            else:
                okay=0
                for item in uploads:
                    try:
                        raw=item.getvalue();mime=validate_upload(item.name,raw)
                        storage.add_document(vacancy,candidate,item.name,cat,mime,raw,actor)
                        okay+=1
                    except Exception as exc:st.error(f'{item.name}: {exc}')
                if okay:st.success(f'{okay} archivo(s) incorporado(s). El expediente debe analizarse o revalidarse.')


def analyze_action(vacancy,candidate):
    key,model=api_details()
    if st.button('🔎 Ejecutar / actualizar análisis',type='primary',key='run_'+candidate):
        try:
            with st.spinner('Extrayendo evidencias y aplicando las bases ficticias...'):
                ana=run_analysis(vacancy,candidate,api_key=key,model=model)
            st.success('Análisis disponible. La revisión humana sigue siendo obligatoria.')
        except Exception as exc:st.error(f'No se pudo analizar el expediente: {type(exc).__name__}: {exc}')


def result_details(case,config):
    result=case['result']
    m1,m2,m3=st.columns(3)
    m1.metric('Puntuación de méritos',f"{result['total']:.2f} / 45")
    m2.metric('Requisitos acreditados',f"{sum(r['status']==ACCREDITED for r in result['requirements'])}/{len(result['requirements'])}")
    m3.metric('Incidencias documentales',len(result['document_issues']))
    if result['contains_fixtures']:
        st.info('🧪 Incluye documentos ficticios creados para la demostración. No hay acreditación auténtica.')
    if result['demonstration']:
        st.warning('Extracción local limitada, SIN modelo de IA configurado. Resultados de demostración y provisionales.')
    st.markdown(f"**Estado:** {case['status']} · **Fecha UTC:** {case['date']}")
    t1,t2,t3=st.tabs(['Requisitos','Baremo de méritos','Incidencias y fuentes'])
    with t1:
        for req in result['requirements']:
            with st.expander(f"{badge(req['status'])} · {req['label']}",expanded=req['status']!=ACCREDITED):
                st.write(req['reason'])
                if req.get('manual'):st.caption('Corrección efectuada por un técnico.')
                show_evidence(req['evidence'])
    with t2:
        for merit in result['merits']:
            with st.expander(f"{merit['label']} — {merit['points']:.2f} / {merit['max_points']}"):
                st.write(merit['reason'])
                if merit.get('manual'):st.caption('Puntuación modificada manualmente con trazabilidad.')
                show_evidence(merit['evidence'])
    with t3:
        for issue in result['document_issues']:
            st.warning(f"{issue['filename']}: {issue['message']}")
        if not result['document_issues']:st.success('Sin incidencias de lectura detectadas.')
        st.caption('Los fragmentos conservan la página o ubicación que pudo recuperarse. La extracción no autentica documentos.')
    st.download_button('⬇️ Descargar informe individual (PDF)',pdf_candidate(case,config),
                       f"informe_{config['code']}_{case['candidate']}.pdf",'application/pdf',key='report_'+case['candidate'])


def review_panel(vacancy,candidate,actor,case):
    st.subheader('Supervisión humana y trazabilidad')
    if not case:st.info('Ejecute el análisis antes de registrar una revisión.');return
    result=case['result']
    st.caption('Cualquier corrección exige usuario y justificación. Tras una nueva versión documental, las revisiones previas permanecen en el historial y deben confirmarse otra vez.')
    history=storage.previous_reviews(vacancy,candidate)
    other=[r for r in history if r['analysis_id']!=case['analysis_id']]
    if other:st.info(f'Existen {len(other)} revisión(es) de análisis anteriores, disponibles en Auditoría; no se aplican automáticamente a documentación modificada.')
    reqtab,merittab,validtab=st.tabs(['Corregir requisito','Corregir puntuación','Validación final humana'])
    with reqtab:
        items=result['requirements']
        req=st.selectbox('Requisito',items,format_func=lambda x:x['label'],key='rsel_'+candidate)
        ix=STATES.index(req['status'])
        with st.form('reqreview_'+case['analysis_id']+'_'+req['id']):
            new_status=st.selectbox('Resultado tras revisión',STATES,index=ix,
                format_func=badge,key='status_'+case['analysis_id']+'_'+req['id'])
            why=st.text_area('Motivación y documentos examinados',max_chars=1000,
                key='why_req_'+case['analysis_id']+'_'+req['id'])
            clicked=st.form_submit_button('Guardar valoración del requisito')
        if clicked:
            try:
                storage.save_review(vacancy,candidate,case['analysis_id'],'requirement',req['id'],
                    {'status':new_status,'reason':why},actor,why)
                st.success('Revisión registrada; las validaciones previas quedan invalidadas.');st.rerun()
            except Exception as exc:st.error(str(exc))
    with merittab:
        merits=result['merits'];merit=st.selectbox('Mérito',merits,format_func=lambda x:x['label'],key='msel_'+candidate)
        with st.form('meritreview_'+case['analysis_id']+'_'+merit['id']):
            newscore=st.number_input('Puntuación revisada',min_value=0.0,max_value=float(merit['max_points']),
                value=float(merit['points']),step=0.5,format='%.2f',
                key='points_'+case['analysis_id']+'_'+merit['id'])
            why=st.text_area('Regla aplicada y justificación de la corrección',max_chars=1000,
                key='why_merit_'+case['analysis_id']+'_'+merit['id'])
            clicked=st.form_submit_button('Guardar puntuación revisada')
        if clicked:
            try:
                storage.save_review(vacancy,candidate,case['analysis_id'],'merit',merit['id'],
                    {'points':float(newscore),'reason':why},actor,why)
                st.success('Puntuación revisada con registro de cambios.');st.rerun()
            except Exception as exc:st.error(str(exc))
    with validtab:
        if case['validated']:
            st.success('Expediente validado por revisión humana. Clasifica como elegible.')
        elif not case['eligible']:
            st.warning('No es posible validar como elegible mientras existan requisitos distintos de Acreditado. Revise cada uno.')
        else:
            st.info('Requisitos acreditados. Confirme también la valoración de méritos y evidencias originales.')
            confirmation=st.checkbox('He contrastado personalmente requisitos, documentos y puntuación, y asumo la validación de este expediente.',
                key='confirm_'+case['analysis_id'])
            if st.button('✅ Validar expediente completo',disabled=not confirmation,type='primary',key='v_'+candidate):
                try:
                    storage.validate_eligibility(vacancy,candidate,case['analysis_id'],actor)
                    st.success('Validación registrada en la auditoría.');st.rerun()
                except Exception as exc:st.error(str(exc))


def page_dashboard(vacancy,config,actor):
    st.title('Panel del proceso selectivo')
    st.write(f"**{config['code']}** · {config['title']} · Referencia: **{config['cutoff_date']}**")
    rows=classification(vacancy)
    a,b,c,d,e=st.columns(5)
    a.metric('Candidaturas',len(rows))
    b.metric('Validadas',sum(r['Validado'] for r in rows))
    c.metric('En revisión',sum('Pendiente' in r['Estado'] or 'No acreditado' in r['Estado'] or r['Estado']=='Sin análisis' for r in rows))
    d.metric('Incumplimientos',sum('Incumplimiento' in r['Estado'] for r in rows))
    e.metric('Incidencias',sum(r['Incidencias'] for r in rows))
    left,right=st.columns([1,2])
    with left:
        key,model=api_details()
        if st.button('🔎 Analizar todas las candidaturas',type='primary'):
            ok=0
            with st.spinner('Analizando expedientes ficticios...'):
                for cnd in storage.list_candidates(vacancy):
                    try:run_analysis(vacancy,cnd['candidate'],key,model);ok+=1
                    except Exception as exc:st.error(f"{cnd['candidate']}: {exc}")
            if ok:st.success(f'{ok} expediente(s) analizados.');st.rerun()
    with right:
        st.caption('Las posiciones solo corresponden a expedientes validados. Los empates comparten posición, sin desempate inventado.')
    st.subheader('Clasificación general')
    q=st.text_input('Buscar candidatura',placeholder='C-001')
    states=['Todos']+sorted(set(r['Estado'] for r in rows))
    state=st.selectbox('Filtrar por estado',states)
    scope=st.radio('Resultados',('Todas las candidaturas','Solo definitivos'),horizontal=True)
    filtered=[r for r in rows if (not q or q.lower() in r['Candidatura'].lower()) and (state=='Todos' or r['Estado']==state)
              and (scope=='Todas las candidaturas' or r['Definitivo'])]
    st.dataframe(pd.DataFrame(filtered),hide_index=True,use_container_width=True,
        column_config={'Puntos':st.column_config.NumberColumn(format='%.2f'),
                       'Validado':st.column_config.CheckboxColumn(), 'Definitivo':st.column_config.CheckboxColumn()})
    st.caption('Herramienta de apoyo a selección; no adopta decisiones de adjudicación ni exclusión por sí sola.')


def page_candidates(vacancy,config,actor):
    st.title('Expediente individual')
    candidate=choose_candidate(vacancy)
    list_document_controls(vacancy,candidate)
    doc_upload(vacancy,candidate,actor)
    analyze_action(vacancy,candidate)
    case=case_result(vacancy,candidate)
    if case:
        st.divider();result_details(case,config)
    else:st.info('Este expediente aún no se ha analizado con la versión actual de las bases y documentos.')
    st.divider()
    review_panel(vacancy,candidate,actor,case)


def page_incidents(vacancy,config,actor):
    st.title('Incidencias y revisión')
    rows=classification(vacancy)
    flagged=[r for r in rows if r['Incidencias'] or not r['Validado']]
    if not flagged:st.success('Sin expedientes pendientes.')
    else:st.dataframe(pd.DataFrame(flagged),hide_index=True,use_container_width=True)
    candidate=choose_candidate(vacancy,'incidents')
    case=case_result(vacancy,candidate)
    if case:
        with st.expander('Evidencias y valoración del expediente',expanded=True):result_details(case,config)
    else:st.warning('Sin análisis vigente. Ejecútelo en Candidaturas.')
    review_panel(vacancy,candidate,actor,case)


def _terms(value):
    return [x.strip() for x in value.split(';') if x.strip()]


def page_config(vacancy,config,actor):
    st.title('Configuración de la convocatoria')
    st.info('Los criterios SOLO cambian por acción del técnico. Cualquier cambio crea una nueva versión; los expedientes requieren un nuevo análisis y revalidación.')
    proposed=copy.deepcopy({k:v for k,v in config.items() if not k.startswith('_')})
    with st.form('config_simple'):
        proposed['title']=st.text_input('Denominación de la plaza',proposed['title'])
        proposed['cutoff_date']=st.text_input('Fecha de referencia (AAAA-MM-DD)',proposed['cutoff_date'])
        tiebreak=proposed.get('tie_breakers',[])
        tie_text=st.text_input('Desempates: IDs de méritos (;), mayor puntuación primero. Vacío = empate sin resolver.',
            '; '.join(t['merit_id'] for t in tiebreak))
        st.markdown('#### Requisitos obligatorios')
        for req in proposed['requirements']:
            st.markdown(f"**{req['id']} — {req['label']}**")
            if req['type']=='degree':
                req['allowed_titles']=_terms(st.text_input('Títulos admitidos, separados por ;','; '.join(req['allowed_titles']),key='c_'+req['id']))
            elif req['type']=='license':
                req['category']=st.text_input('Categoría',req['category'],key='c_'+req['id'])
            elif req['type']=='experience':
                req['min_days']=st.number_input('Días mínimos',min_value=1,value=req['min_days'],step=1,key='cmin_'+req['id'])
                req['function_keywords']=_terms(st.text_input('Funciones acreditables (;)', '; '.join(req['function_keywords']),key='c_'+req['id']))
            elif req['type']=='training':
                req['min_hours']=st.number_input('Horas mínimas',min_value=1,value=req['min_hours'],key='cmin_'+req['id'])
                req['topic_keywords']=_terms(st.text_input('Temas admitidos (;)', '; '.join(req['topic_keywords']),key='c_'+req['id']))
        st.markdown('#### Baremo de méritos')
        newthresholds={}
        for merit in proposed['merits']:
            st.markdown(f"**{merit['id']} — {merit['label']}**")
            merit['max_points']=st.number_input('Puntuación máxima (múltiplos de 5)',min_value=5,max_value=45,step=5,
                value=merit['max_points'],key='max_'+merit['id'])
            rule=merit['rule']
            if rule['kind']=='full_blocks':
                rule['days_per_block']=st.number_input('Días de experiencia por bloque',min_value=1,value=rule['days_per_block'],key='days_'+merit['id'])
                rule['points_per_block']=st.number_input('Puntos por bloque',min_value=1,value=int(rule['points_per_block']),key='pts_'+merit['id'])
                rule['function_keywords']=_terms(st.text_input('Funciones (;)', '; '.join(rule['function_keywords']),key='terms_'+merit['id']))
            else:
                rule['topic_keywords']=_terms(st.text_input('Temática (;)', '; '.join(rule['topic_keywords']),key='terms_'+merit['id']))
                if rule['kind']=='hours_steps':
                    original='; '.join(f"{step['min_hours']}:{step['points']}" for step in rule['thresholds'])
                    newthresholds[merit['id']]=st.text_input('Tramos horas:puntos (;)', original,key='thr_'+merit['id'])
                else:
                    rule['min_hours']=st.number_input('Horas mínimas de cada curso',min_value=0,value=rule['min_hours'],key='hours_'+merit['id'])
                    rule['points_per_course']=st.number_input('Puntos por curso',min_value=1,value=int(rule['points_per_course']),key='ppc_'+merit['id'])
        submitted=st.form_submit_button('Guardar configuración y crear nueva versión',type='primary')
    if submitted:
        try:
            proposed['tie_breakers']=[{'merit_id':v,'direction':'desc'} for v in _terms(tie_text)]
            for merit in proposed['merits']:
                if merit['id'] in newthresholds:
                    merit['rule']['thresholds']=[{'min_hours':int(part.strip().split(':')[0]),
                        'points':int(part.strip().split(':')[1])} for part in newthresholds[merit['id']].split(';') if part.strip()]
            validate_config(proposed)
            storage.save_config(vacancy,proposed,actor)
            st.success('Configuración guardada y versionada.');st.rerun()
        except (ValueError,ConfigurationError,IndexError,KeyError) as exc:st.error(f'No se aplicaron cambios: {exc}')
    with st.expander('Configuración completa (JSON avanzado, solo usuarios técnicos)'):
        with st.form('config_json'):
            raw=st.text_area('JSON editable',value=json.dumps({k:v for k,v in config.items() if not k.startswith('_')},
                ensure_ascii=False,indent=2),height=350)
            save=st.form_submit_button('Validar y guardar JSON')
        if save:
            try:
                updated=json.loads(raw);validate_config(updated)
                storage.save_config(vacancy,updated,actor)
                st.success('Bases actualizadas.');st.rerun()
            except (ValueError,ConfigurationError) as exc:st.error(f'Configuración rechazada: {exc}')
    st.caption(f'Versión vigente: {config["_version"]}. Total de máximos: {sum(m["max_points"] for m in config["merits"])} / 45 puntos.')


def page_exports(vacancy,config):
    st.title('Exportación de resultados')
    rows=classification(vacancy)
    audit=storage.audit_list(vacancy)
    datasets=export_rows(vacancy,rows,audit)
    st.write('Todos los archivos incluyen el identificador de convocatoria, estado y fecha de exportación (UTC).')
    l,r=st.columns(2)
    l.download_button('⬇️ Clasificación CSV',csv_bytes(datasets['Clasificacion']),f'clasificacion_{vacancy}.csv','text/csv')
    r.download_button('⬇️ Clasificación + incidencias + auditoría (Excel)',excel_bytes(datasets),f'resultados_{vacancy}.xlsx',
                      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    l,r=st.columns(2)
    l.download_button('⬇️ Incidencias CSV',csv_bytes(datasets['Incidencias']),f'incidencias_{vacancy}.csv','text/csv')
    r.download_button('⬇️ Historial CSV',csv_bytes(datasets['Auditoria']),f'historial_{vacancy}.csv','text/csv')
    st.subheader('Informes individuales PDF')
    candidate=choose_candidate(vacancy,'reportexport')
    case=case_result(vacancy,candidate)
    if case:
        st.download_button('⬇️ Informe PDF',pdf_candidate(case,config),f'informe_{vacancy}_{candidate}.pdf','application/pdf')
    else:st.info('Analice la candidatura antes de emitir un informe individual.')


def page_audit(vacancy):
    st.title('Registro de cambios')
    st.caption('Se incluyen versiones de documentos (sin exponer su contenido), cambios humanos, modificaciones de bases y validaciones.')
    rows=storage.audit_list(vacancy)
    if rows:
        items=[{'Fecha UTC':r['changed_at'],'Candidatura':r['candidate'],'Acción':r['action'],
            'Usuario':r['actor'],'Motivo':r['reason'],'Antes':r['before_json'],'Después':r['after_json']} for r in rows]
        st.dataframe(pd.DataFrame(items),hide_index=True,use_container_width=True)
    else:st.info('Sin modificaciones registradas.')


def main():
    storage.initialize()
    actor=controlled_actor()
    st.sidebar.markdown('## 📑 Baremador RRHH')
    allvac=storage.vacancies()
    search=st.sidebar.text_input('Buscar por código de vacante')
    matched=[v for v in allvac if search.lower() in v['code'].lower()]
    if not matched:
        st.error('No existe una convocatoria que coincida con la búsqueda.');st.stop()
    vacancy=st.sidebar.selectbox('Convocatoria',matched,format_func=lambda x:x['code']+' · '+x['title'])['code']
    config=storage.get_config(vacancy)
    options=['Panel general','Candidaturas','Incidencias y revisión','Configurar convocatoria','Exportar resultados','Auditoría']
    nav=st.sidebar.radio('Navegación',options,label_visibility='visible')
    st.sidebar.divider()
    st.sidebar.caption('Prototipo académico · documentación y procesos 100 % ficticios · sin conexión a Tragsa.')
    key,_=api_details()
    st.sidebar.caption('Motor documental: '+('IA configurada + reglas Python' if key else 'demostración local sin IA'))
    if nav=='Panel general':page_dashboard(vacancy,config,actor)
    elif nav=='Candidaturas':page_candidates(vacancy,config,actor)
    elif nav=='Incidencias y revisión':page_incidents(vacancy,config,actor)
    elif nav=='Configurar convocatoria':page_config(vacancy,config,actor)
    elif nav=='Exportar resultados':page_exports(vacancy,config)
    else:page_audit(vacancy)


if __name__=='__main__':main()
