# Baremador documental y de candidaturas — prototipo académico

Aplicación de **Python + Streamlit** para explorar convocatorias ficticias, extraer campos de documentos, comprobar requisitos, calcular méritos **con reglas deterministas**, corregir valoraciones con trazabilidad, validar expedientes por revisión humana y exportar los resultados. Inspirado en las necesidades generales de selección pública, **sin relación tecnológica ni administrativa con Grupo Tragsa**.

> **SOLO DEMOSTRACIÓN.** Todos los expedientes precargados son inventados. No subir documentos reales, información personal ni credenciales corporativas. No usar para procesos reales de selección ni como sistema de decisión automática.

## 1. Ejecutar localmente

Recomendado Python **3.12** o compatible.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

La primera ejecución crea una base SQLite local en `data/runtime.sqlite`, con dos convocatorias, seis candidaturas ficticias y documentos DOCX ficticios que se procesan de verdad. La base local se puede reiniciar borrando `data/runtime.sqlite` con la aplicación cerrada.

**Flujo de demostración recomendado**: (1) seleccionar TR-DEMO-001, (2) pulsar «Analizar todas las candidaturas», (3) entrar en `Candidaturas`, (4) visualizar pruebas y puntuaciones, (5) corregir una valoración con justificación, (6) validar manualmente un expediente elegible, (7) consultar la clasificación definitiva y (8) exportar el informe PDF y el Excel.

Sin API: extracción conservadora de formularios tipo `Etiqueta: valor`, **modo demostración, sin IA**, señalado expresamente en la interfaz e informes. Los campos se extraen del contenido de DOCX, PDF, JPG y PNG; los ejemplos no son puntuaciones hardcodeadas.

## 2. Activar IA o una contraseña (opcional)

Copiar `.streamlit/secrets.toml.example` a `.streamlit/secrets.toml` y sustituir los valores de ejemplo. Nunca subir este segundo archivo a GitHub: está protegido por `.gitignore`.

```toml
[auth]
reviewer_password = "UNA_CONTRASEÑA_EXTENSA"

[openai]
api_key = "TU_CLAVE_API"
model = "gpt-4o-mini"
```

El modelo de lenguaje intenta proponer campos estructurados; **solo se conservan los campos cuyo valor se verifica dentro del texto extraído**. La extracción mediante OCR puede ser errónea. Toda identificación y toda puntuación siguen siendo provisionales y deben ser supervisadas. Las llamadas a API requieren Internet y pueden generar costes. Si la API falla, se indica la incidencia y se usa el extractor limitado de demostración.

La contraseña compartida es **solo protección básica para la demo**, no autorización granular, SSO ni un mecanismo de acceso listo para producción. Si no se configura, la aplicación queda abierta a cualquier visitante con acceso a su URL (exclusivamente para datos inventados).

## 3. Desplegar en Streamlit Community Cloud

1. Crear un repositorio de GitHub, preferentemente privado, y subir todos los archivos del proyecto **excepto** SQLite local, secretos y directorios ignorados.
2. Entrar en [share.streamlit.io](https://share.streamlit.io/), seleccionar **Create app**, indicar repositorio, rama y `app.py`.
3. En **Advanced settings**, utilizar Python 3.12 (o versión soportada), y configurar los secretos de la aplicación si se necesitan. Nunca subir claves al repositorio.
4. Streamlit instalará `requirements.txt` y los paquetes del sistema declarados en `packages.txt` (Tesseract y OCR español). La aplicación muestra expedientes ficticios automáticamente.
5. **Importante**: la SQLite almacenada en el sistema de archivos de Community Cloud **no es persistencia de producción**: una reconstrucción, nueva instancia o reinicio puede perder cambios. Para una demostración larga con revisión multiusuario, sustituir SQLite por una base administrada y añadir autenticación fuerte.

Documentación oficial: [Despliegue](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy), [Dependencias](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/app-dependencies) y [Secrets](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/secrets-management).

## 4. Estructura

```text
app.py                          Interfaz Streamlit
core/config.py                  Validación de reglas configurables
core/storage.py                 SQLite, documentos, análisis, revisiones y auditoría
core/extraction.py              PDF/DOCX/OCR + extractor local e IA opcional
core/evaluation.py              Requisitos y puntos deterministas, períodos sin solapes
core/service.py                 Orquestación y clasificación humana
core/reports.py                 PDF, CSV, Excel
 data/convocatorias.json        Bases de 2 convocatorias ficticias
 data/candidatos.json           6 candidaturas anónimas inventadas
 data/documentos_demo.json     Semillas que generan archivos DOCX
 tests/test_prototype.py        Pruebas automáticas
 requirements.txt               Dependencias Python
 packages.txt                   OCR de sistema para Community Cloud
 .streamlit/config.toml         Tema visual
 .streamlit/secrets.toml.example Plantilla NO secreta
```

## 5. Modelo de evaluación, límites y reglas

- El modelo de lenguaje **solo identifica campos**; no decide puntuaciones.
- Títulos: solo coincidencia explícita con títulos admitidos; una equivalencia oficial no se infiere automáticamente.
- Permisos: categoría y vigencia respecto de la fecha de referencia de la convocatoria. No se comprueba autenticidad del permiso.
- Experiencia: contratos y certificados con **funciones expresas**; la vida laboral aislada no acredita funciones. Uniones de días de intervalos inclusivos, sin sumar dos veces períodos coincidentes.
- Formación: horas y criterios temáticos configurados; se evita puntuar dos veces un mismo curso con título, emisor y fecha idénticos.
- Puntuación: `full_blocks` (bloques completos con redondeo hacia abajo explícito), `hours_steps` (tramos definidos) y `per_course` (puntos por curso), con límites por criterio y suma no superior a 45.
- **No se inventa desempate**: sin reglas de desempate, las candidaturas con igual puntuación comparten posición. Si las bases configuran expresamente prioridades por puntuación de méritos, se aplican de forma determinista. Los empates aún no resueltos deben examinarse manualmente.
- Requisitos: **Acreditado / No acreditado / Incumplimiento verificado / Pendiente de revisión**. Una ausencia documental no es automáticamente incumplimiento.
- Solo los expedientes con todos los requisitos acreditados **y validados expresamente por un humano** figuran en la clasificación definitiva. No se automatiza adjudicación ni exclusión.
- Una modificación de archivos o bases genera una versión nueva que requiere análisis y **nueva validación**, y mantiene historial/auditoría de valoraciones antiguas. Si se repite el análisis sin cambios, se reutiliza el análisis previo.
- Los documentos de prueba y la interpretación heurística sin API están diferenciados de los documentos auténticos y las conclusiones verificadas.

## 6. Pruebas

```bash
pip install pytest
python -m pytest -q
```

Se cubren extracción DOCX, estados de requisitos, permisos caducados, ausencia de documentos, fechas contradictorias, prevención de solapes, límite de 45 puntos, validación humana, correcciones/auditoría, cambios de versión, exportaciones y rechazo de configuraciones erróneas.

## 7. Limitaciones para un despliegue empresarial

No cuenta con una integración real con plataformas corporativas; no realiza verificación oficial de titulaciones, permisos ni certificados; no incorpora normalización completa de documentos reales, cotejo de identidades, firma digital, SSO/RBAC, control de acceso por expediente a nivel de infraestructura, cifrado de información personal en reposo, gestión de retención, monitorización, ni persistencia transaccional distribuida. El modo local/IA no elimina alucinaciones y puede ignorar información válida. Para un uso con personas reales harían falta evaluación de impacto, asesoramiento jurídico (RGPD y regulación aplicable de IA), pruebas de sesgo/precisión con conjuntos autorizados, controles de calidad del OCR, supervisión humana y trazabilidad organizativa, homologación de seguridad, respaldo y sistema de apelación y rectificación.

El prototipo no reproduce bases reales de ninguna convocatoria ni debe considerarse aprobado o certificado por la entidad de referencia.
